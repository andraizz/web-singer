@extends('layouts.main')

@section('container')
<h1>List Produk</h1>
    <h6>Temukan mesin jahit blabalbalbal</h6>
    <div class="container p-4">
        <div class="row">
            <div class="col-6 col-sm-4 col-lg-4">
                <div class="card">
                    <img src="img/heavy4411.png" alt="Heavy Duty 4411">
                </div>
                <h2>Heavy Duty 4411</h2>
                <a href="/detail_product" class="btn btn-danger">Learn More</a>
            </div>
            <div class="col-6 col-sm-4 col-lg-4">
                <div class="card">
                    <img src="img/heavy4411.png" alt="Heavy Duty 4411">
                </div>
                <h2>Heavy Duty 4423</h2>
                <a href="" class="btn btn-danger">Learn More</a>
            </div>
            <div class="col-6 col-sm-4 col-lg-4">
                <div class="card">
                    <img src="img/heavy4411.png" alt="Heavy Duty 4411">
                </div>
                <h2>Heavy Duty 4432</h2>
                <a href="" class="btn btn-danger">Learn More</a>
            </div>
        </div>
    </div>
@endsection