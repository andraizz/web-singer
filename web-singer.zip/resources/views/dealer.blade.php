@extends('layouts.main')

@section('container')
  <h1>Our Dealer</h1>
@endsection