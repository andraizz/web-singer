@extends('layouts.main')

@section('container')
  <h1>Service Center Singer Indonesia</h1>
@endsection