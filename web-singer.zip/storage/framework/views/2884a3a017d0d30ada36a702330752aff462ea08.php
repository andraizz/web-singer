

<?php $__env->startSection('container'); ?>

<section id="about">
    <div class="container">
        <div class="header text-center">
            <img src="img/singer.jpeg" class="img-fluid mb-3" alt="singer jakarta">
        </div>
        <div class="row justify-content-center">
            <div class="col-10">
                <p class="text-center fs-5 mb-0"><b>Singer Jakarta</b> adalah toko online yang menjual produk mesin jahit bermerk Singer dengan kualitas terbaik dan bergaransi resmi. Mesin jahit SINGER bertahan hingga hari ini karena komitmen terhadap kualitas,
                    inovasi, dan layanan untuk Anda
                </p>
            </div>
        </div>
    </div>
</section>
<hr>
<section id="services">
    <div class="container">
        <div class="header text-center">
            <h3>Pelayanan</h3>
            <p>Beberapa pelayanan dari singer jakarta untuk para konsumen</p>
        </div>
        <div class="row">
            <div class="col-12 col-sm-12 col-md-12 col-lg-4">
                <div class="card p-3 mb-3 shadow">
                    <div class="row align-items-center">
                        <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                            <i class="fa-solid fa-truck-fast"></i>
                        </div>
                        <div class="col-10 col-sm-10 col-md-10 col-lg-10">
                            <h6 class="card-title fw-bold">Gratis Ongkos Kirim</h6>
                            <p class="card-text mb-0"><b>Gratis</b> ongkos kirim wilayah Jakarta dan sekitarnya</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-4">
                <div class="card p-3 mb-3 shadow">
                    <div class="row align-items-center">
                        <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                            <i class="fa-solid fa-gears"></i>
                        </div>
                        <div class="col-10 col-sm-10 col-md-10 col-lg-10">
                            <h6 class="card-title fw-bold">Pelatihan Penggunaan Mesin</h6>
                            <p class="card-text mb-0">Pelatihan penggunan dan perawatan mesin akan kami bantu di workshop kami secara <b>GRATIS</b></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-4">
                <div class="card p-3 mb-3 shadow">
                    <div class="row align-items-center">
                        <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                            <i class="fa-solid fa-credit-card"></i>
                        </div>
                        <div class="col-10 col-sm-10 col-md-10 col-lg-10">
                            <h6 class="card-title fw-bold">Sistem Pembayaran</h6>
                            <p class="card-text mb-0"><b>COD</b> setelah barang diterima khusus wilayah Jakarta dan Depok, <b>Kartu Kredit</b> (Free Charge), <b>Debit/Tunai</b> dan <b>Transfer bank</b></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-4">
                <div class="card p-3 mb-3 shadow">
                    <div class="row align-items-center">
                        <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                            <i class="fa-solid fa-headset"></i>
                        </div>
                        <div class="col-10 col-sm-10 col-md-10 col-lg-10">
                            <h6 class="card-title fw-bold">Staff Marketing</h6>
                            <p class="card-text mb-0">Telpon 02187753821 atau Whatsapp 081383521987</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-4">
                <div class="card p-3 mb-3 shadow">
                    <div class="row align-items-center">
                        <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                            <i class="fa-solid fa-tags"></i>
                        </div>
                        <div class="col-10 col-sm-10 col-md-10 col-lg-10">
                            <h6 class="card-title fw-bold">Layanan Service</h6>
                            <p class="card-text mb-0">Layanan Service datang ke rumah untuk wilayah Jakarta dan sekitarnya (area tertentu)</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-12 col-md-12 col-lg-4">
                <div class="card p-3 mb-3 shadow">
                    <div class="row align-items-center">
                        <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                            <i class="fa-solid fa-gift"></i>
                        </div>
                        <div class="col-10 col-sm-10 col-md-10 col-lg-10">
                            <h6 class="card-title fw-bold">Bonus Pembelian</h6>
                            <p class="card-text mb-0">Kami berikan bonus pada type-type tertentu setiap pembelian</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<hr>
<section id="olshop">
    <div class="container">
        <div class="header text-center">
            <h3>Temukan Kami</h3>
            <p>Temukan singer jakarta di sosial media dan online shop kami</p>
        </div>
        <div class="row justify-content-center text-center">
            <div class="col-4 col-sm-4 col-md-4 col-lg-2 mb-3">
                <a href="https://www.facebook.com/singerjakarta/" target="blank" title="Temukan kami di Facebook"><img width="40" height="40" src="<?php echo e(asset('img/facebook.png')); ?>"></a>
            </div>
            <div class="col-4 col-sm-4 col-md-4 col-lg-2 mb-3">
                <a href="https://instagram.com/huwa_mesin" target="blank" title="Temukan kami di Instagram"><img width="40" height="40" src="<?php echo e(asset('img/instagram.png')); ?>"></a>
            </div>
            <div class="col-4 col-sm-4 col-md-4 col-lg-2 mb-3">
                <a href="https://shopee.co.id/tokowiramesin" target="blank" title="Temukan kami di Shopee"><img width="40" height="40" src="<?php echo e(asset('img/shopee.png')); ?>"></a>
            </div>
            <div class="col-4 col-sm-4 col-md-4 col-lg-2 mb-3">
                <a href="https://tokopedia.com/huwasewing" target="blank" title="Temukan kami di Tokopedia"><img width="40" height="40" src="<?php echo e(asset('img/tokopedia.png')); ?>"></a>
            </div>
            <div class="col-4 col-sm-4 col-md-4 col-lg-2 mb-3">
                <a href="https://www.bukalapak.com/u/singer_dijakarta" target="blank" title="Temukan kami di Bukalapak"><img width="40" height="40" src="<?php echo e(asset('img/bukalapak.png')); ?>"></a>
            </div>
            <div class="col-4 col-sm-4 col-md-4 col-lg-2 mb-3">
                <a href="https://www.blibli.com/merchant/singer-jakarta/SIJ-60034?page=1&start=0&pickupPointCode=&cnc=&multiCategory=true&sort=7" target="blank" title="Temukan kami di Blibli"><img width="40" height="40" src="<?php echo e(asset('img/blibli.png')); ?>"></a>
            </div>
        </div>
        <div class="row justify-content-center text-center">
            <div class="col-8">
                <p class="small text-danger">Buka Senin s/d Minggu & Hari BesarTerkecuali Idul Fitri Pukul jam 09.00 s/d jam 19.00</p>
            </div>
        </div>
    </div>
</section>
<hr>
<section id="bank">
	<div class="container">
        <div class="header text-center">
            <h3>Rekening Bank</h3>
            <p>Berikut ini adalah detail akun rekening bank kami, mohon untuk berhati-hati terhadap penipuan yang mengatas namakan toko online kami.</p>
        </div>
		<div class="row justify-content-center text-center">
			<div class="col-5">
				<img src="https://upload.wikimedia.org/wikipedia/commons/5/5c/Bank_Central_Asia.svg" class="img-fluid mb-2" alt="bca" width="200">
				<p>Rek. 6870601229</p>
				<p>An. SUHATTA PUTRA</p>
			</div>
			<div class="col-5">
				<img src="https://upload.wikimedia.org/wikipedia/commons/a/ad/Bank_Mandiri_logo_2016.svg" class="img-fluid mb-2" alt="mandiri" width="200">
				<p>Rek. 1560003456128</p>
				<p>An. SUHATTA PUTRA</p>
			</div>											
		</div>
	</div>
</section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andra\OneDrive\Documents\Andraaaa\Project\web-singer\resources\views/home.blade.php ENDPATH**/ ?>